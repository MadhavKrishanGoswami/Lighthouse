To install, run the following command in your terminal: sudo ./install-agent.sh
