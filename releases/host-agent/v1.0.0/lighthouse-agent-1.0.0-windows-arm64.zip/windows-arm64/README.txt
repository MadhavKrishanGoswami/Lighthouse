To install, right-click 'install-agent.bat' and select 'Run as administrator'.
