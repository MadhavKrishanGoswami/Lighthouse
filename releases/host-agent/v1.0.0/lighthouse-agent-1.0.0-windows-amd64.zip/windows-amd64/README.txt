To install, right-click 'install.bat' and select 'Run as administrator'.
